/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticket;

import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author ferna
 */
public class eventoDeportivo extends Evento {
    public String team1,team2;
    public ArrayList<String> jugadoresteam1= new ArrayList();
    public ArrayList<String> jugadoresteam2= new ArrayList();
    public eventoDeportivo(String code, String title, String description, Date date,double monto,String team1,String team2){
        super(code,title,description,date,monto);
        this.team1=team1;
        this.team2=team2;
    }
    public enum deporte{
        FUTBOL,TENIS,RUGBY,BASEBALL;
    }
    @Override
    public double seguro(){
        return 0;
    }
    @Override
    public boolean maxCapacity(int personas){
        if(personas>20000)
            return false;
            return true;
    }
    @Override
     public String findObject(){
         monto+=seguro();
        return "Codigo: "+code+" Titulo: "+title+" Descripcion: "+description+" Fecha: "+date+" Monto: "+monto;
    }
    public void addPlayers(String name,String teamname){
        if(teamname.equalsIgnoreCase(team1))
            jugadoresteam1.add(name);
        else if(teamname.equalsIgnoreCase(team2))
            jugadoresteam2.add(name);
        else JOptionPane.showMessageDialog(null, "Ingrese el nombre de uno de los dos equipos que participan en el evento");
    }
    public double multa(double multa){
        this.multa+=multa;
        return this.multa;
    }
}
