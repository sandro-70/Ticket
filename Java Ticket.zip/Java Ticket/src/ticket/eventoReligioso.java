/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticket;

import java.util.Date;

/**
 *
 * @author ferna
 */
public class eventoReligioso extends Evento{
    
    
    public eventoReligioso(String code, String title, String description, Date date,double monto){
        super(code,title,description,date,monto);
        
    }
    @Override
    public final double seguro(){
        return 2000;
    }
    @Override
    public boolean maxCapacity(int personas){
        if(personas>30000)
            return false;
            return true;
    }
    @Override
     public String findObject(){
         monto+=seguro();
        return "Codigo: "+code+" Titulo: "+title+" Descripcion: "+description+" Fecha: "+date+" Monto: "+monto;
    }
    public int addConvertidos(int convertidos){
        return convertidos;
    }
    public double multa(double multa){
        return 0;
    }
    
}
