/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticket;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author ferna
 */
public abstract class Evento implements tracking {
    protected String code;
    protected String title;
    protected String description;
    protected Date date;
    protected double monto;
    protected String estado;
    protected boolean cancelado;
    protected double multa;

    public Evento(String code, String title, String description, Date date,double monto) {
        this.code = code;
        this.title = title;
        this.description = description;
        this.date = date;
        this.monto=monto;
    }
    public String findObject(){
        return "Codigo: "+code+" Titulo: "+title+" Descripcion: "+description+" Fecha: "+date+" Monto: "+monto;
    }
    
    protected abstract double seguro();
    protected abstract boolean maxCapacity(int personas);
    protected abstract double multa(double multa);
    protected void checkEstado(Date date){
        if(this.date.after(date)&&this.date.getDate()+1==date.getDate()){
            estado="El evento no ha ocurrido y se cobrara una multa por cancelacion";
        estado(true);
    }
        else if(this.date.after(date)){
            estado="El evento no ha ocurrido";
            estado(true);
        }
        else if(this.date.before(date)){
            estado="El evento ya ocurrio";
            estado(false);
        }
    }
    protected boolean estado(boolean estado){
        cancelado=estado;
        return cancelado;
    }
   
    
}
