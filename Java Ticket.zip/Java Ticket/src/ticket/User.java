/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticket;


import java.util.ArrayList;

/**
 *
 * @author ferna
 */
public abstract class User implements tracking {
    protected String name;
    protected String username;
    protected String password;
    protected int age;
    protected ArrayList<Evento> createdEvents;

    public User(String name, String username, String password, int age) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.age = age;
    }
    
    public abstract String userCategory();
    public abstract int showEvents(int n);
    public String addEvent(String id,String tipo,String titulo,String estado,double monto){
        return "ID del Evento: "+id+" Tipo de Evento: "+tipo+" Titulo del Evento: "+titulo+" Estado: "+estado+" Monto: "+monto;
    }
           
    
    @Override
    public String findObject(){
        return "Nombre Completo: "+name+" Username: "+username+" Edad: "+age;
    }
    public void addEventinfo(Evento event){
        createdEvents.add(event);
    }
        
    
}
