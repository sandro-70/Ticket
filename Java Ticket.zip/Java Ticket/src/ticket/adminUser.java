/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticket;

import java.util.ArrayList;

/**
 *
 * @author ferna
 */
public class adminUser extends User{
    public static ArrayList<String> EventID;
    public String category;
    public adminUser(String name, String user, String password,int age,String category){
        super(name,user,password,age);
        this.category=category;
    }
    public String userCategory(){
        return category;
    }
    @Override
    public String findObject(){
        return super.toString()+" Categoria: "+category;
    }
    @Override
    public String addEvent(String id,String tipo,String titulo,String estado,double monto){
        EventID.add(super.addEvent(id, tipo, titulo, estado, monto));
        return "Evento agregado exitosamente";
    }
    
    public int showEvents(int n){
        if(n<EventID.size()){
            System.out.println(EventID.get(n));
            return showEvents(n+1);
        }
        return -1;
    }
}
