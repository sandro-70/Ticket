/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticket;

import java.util.ArrayList;

/**
 *
 * @author ferna
 */
public class limitedUser extends User {
  
    public String category;
    public limitedUser(String name, String user, String password,int age,String category){
        super(name,user,password,age);
        this.category=category;
    }
    public String userCategory(){
        return category;
    }
    @Override
    public String findObject(){
        return super.toString()+" Categoria: "+category;
    }
    @Override
    public int showEvents(int n){
        return -2;
    }
}
