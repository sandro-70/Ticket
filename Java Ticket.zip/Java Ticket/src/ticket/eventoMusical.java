/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticket;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author ferna
 */
public class eventoMusical extends Evento{
    public ArrayList<String> integrantes= new ArrayList();
    public eventoMusical(String code, String title, String description, Date date,double monto){
        super(code,title,description,date,monto);
    }
    public enum tipoMusica{
        POP,ROCK,RAP,CLASICA,REGGAETON,OTRO;
    }
    @Override
    public boolean maxCapacity(int personas){
        if(personas>25000)
            return false;
            return true;        
    }
    @Override
    public double seguro(){
        return super.monto*0.3;
    }
    @Override
     public String findObject(){
         monto+=seguro();
        return "Codigo: "+code+" Titulo: "+title+" Descripcion: "+description+" Fecha: "+date+" Monto: "+monto;
    }
    public void addParticipants(String name, String description){
        integrantes.add(name+" Cargo: "+description);
    }
    public double multa(double multa){
        this.multa+=multa;
        return this.multa;
    }
}
